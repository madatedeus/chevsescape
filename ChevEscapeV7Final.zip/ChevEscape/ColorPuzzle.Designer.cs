﻿namespace ChevEscape
{
    partial class ColorPuzzle
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.color_blockB = new System.Windows.Forms.PictureBox();
            this.color_blockA = new System.Windows.Forms.PictureBox();
            this.actionTile_cbA1 = new System.Windows.Forms.PictureBox();
            this.main_player = new System.Windows.Forms.PictureBox();
            this.actionTile_cbA2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbA3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbA4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbB1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbB2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbB3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbB4 = new System.Windows.Forms.PictureBox();
            this.color_blockC = new System.Windows.Forms.PictureBox();
            this.actionTile_cbC1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbC2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbC3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbC4 = new System.Windows.Forms.PictureBox();
            this.color_blockD = new System.Windows.Forms.PictureBox();
            this.color_blockE = new System.Windows.Forms.PictureBox();
            this.color_blockF = new System.Windows.Forms.PictureBox();
            this.color_blockG = new System.Windows.Forms.PictureBox();
            this.color_blockH = new System.Windows.Forms.PictureBox();
            this.color_blockI = new System.Windows.Forms.PictureBox();
            this.actionTile_cbD1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbD2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbD3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbD4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbE1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbE2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbE3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbE4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbF1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbF2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbF3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbF4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbG1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbG2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbG3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbG4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbH1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbH2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbH3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbH4 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbI1 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbI2 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbI3 = new System.Windows.Forms.PictureBox();
            this.actionTile_cbI4 = new System.Windows.Forms.PictureBox();
            this.instructionsIcon = new System.Windows.Forms.PictureBox();
            this.actionTile_Instructions = new System.Windows.Forms.PictureBox();
            this.door_PB = new System.Windows.Forms.PictureBox();
            this.actionTile_Door = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.indicatorPB = new System.Windows.Forms.PictureBox();
            this.heartContainerA = new System.Windows.Forms.PictureBox();
            this.heartContainerC = new System.Windows.Forms.PictureBox();
            this.heartContainerB = new System.Windows.Forms.PictureBox();
            this.button_mute = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockE)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockF)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockG)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockH)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockI)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).BeginInit();
            this.SuspendLayout();
            // 
            // color_blockB
            // 
            this.color_blockB.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockB.Location = new System.Drawing.Point(594, 327);
            this.color_blockB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockB.Name = "color_blockB";
            this.color_blockB.Size = new System.Drawing.Size(64, 62);
            this.color_blockB.TabIndex = 11;
            this.color_blockB.TabStop = false;
            // 
            // color_blockA
            // 
            this.color_blockA.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockA.Location = new System.Drawing.Point(262, 327);
            this.color_blockA.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockA.Name = "color_blockA";
            this.color_blockA.Size = new System.Drawing.Size(64, 62);
            this.color_blockA.TabIndex = 10;
            this.color_blockA.TabStop = false;
            // 
            // actionTile_cbA1
            // 
            this.actionTile_cbA1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbA1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbA1.Location = new System.Drawing.Point(338, 327);
            this.actionTile_cbA1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbA1.Name = "actionTile_cbA1";
            this.actionTile_cbA1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbA1.TabIndex = 9;
            this.actionTile_cbA1.TabStop = false;
            // 
            // main_player
            // 
            this.main_player.BackColor = System.Drawing.Color.Transparent;
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_walkingDown;
            this.main_player.Location = new System.Drawing.Point(1128, 1085);
            this.main_player.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(64, 62);
            this.main_player.TabIndex = 3;
            this.main_player.TabStop = false;
            // 
            // actionTile_cbA2
            // 
            this.actionTile_cbA2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbA2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbA2.Location = new System.Drawing.Point(262, 400);
            this.actionTile_cbA2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbA2.Name = "actionTile_cbA2";
            this.actionTile_cbA2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbA2.TabIndex = 12;
            this.actionTile_cbA2.TabStop = false;
            // 
            // actionTile_cbA3
            // 
            this.actionTile_cbA3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbA3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbA3.Location = new System.Drawing.Point(186, 327);
            this.actionTile_cbA3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbA3.Name = "actionTile_cbA3";
            this.actionTile_cbA3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbA3.TabIndex = 13;
            this.actionTile_cbA3.TabStop = false;
            // 
            // actionTile_cbA4
            // 
            this.actionTile_cbA4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbA4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbA4.Location = new System.Drawing.Point(262, 254);
            this.actionTile_cbA4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbA4.Name = "actionTile_cbA4";
            this.actionTile_cbA4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbA4.TabIndex = 14;
            this.actionTile_cbA4.TabStop = false;
            // 
            // actionTile_cbB1
            // 
            this.actionTile_cbB1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbB1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbB1.Location = new System.Drawing.Point(670, 327);
            this.actionTile_cbB1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbB1.Name = "actionTile_cbB1";
            this.actionTile_cbB1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbB1.TabIndex = 15;
            this.actionTile_cbB1.TabStop = false;
            // 
            // actionTile_cbB2
            // 
            this.actionTile_cbB2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbB2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbB2.Location = new System.Drawing.Point(594, 400);
            this.actionTile_cbB2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbB2.Name = "actionTile_cbB2";
            this.actionTile_cbB2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbB2.TabIndex = 16;
            this.actionTile_cbB2.TabStop = false;
            // 
            // actionTile_cbB3
            // 
            this.actionTile_cbB3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbB3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbB3.Location = new System.Drawing.Point(518, 327);
            this.actionTile_cbB3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbB3.Name = "actionTile_cbB3";
            this.actionTile_cbB3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbB3.TabIndex = 17;
            this.actionTile_cbB3.TabStop = false;
            // 
            // actionTile_cbB4
            // 
            this.actionTile_cbB4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbB4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbB4.Location = new System.Drawing.Point(594, 254);
            this.actionTile_cbB4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbB4.Name = "actionTile_cbB4";
            this.actionTile_cbB4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbB4.TabIndex = 18;
            this.actionTile_cbB4.TabStop = false;
            // 
            // color_blockC
            // 
            this.color_blockC.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockC.Location = new System.Drawing.Point(950, 327);
            this.color_blockC.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockC.Name = "color_blockC";
            this.color_blockC.Size = new System.Drawing.Size(64, 62);
            this.color_blockC.TabIndex = 19;
            this.color_blockC.TabStop = false;
            // 
            // actionTile_cbC1
            // 
            this.actionTile_cbC1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbC1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbC1.Location = new System.Drawing.Point(874, 327);
            this.actionTile_cbC1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbC1.Name = "actionTile_cbC1";
            this.actionTile_cbC1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbC1.TabIndex = 20;
            this.actionTile_cbC1.TabStop = false;
            // 
            // actionTile_cbC2
            // 
            this.actionTile_cbC2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbC2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbC2.Location = new System.Drawing.Point(1026, 327);
            this.actionTile_cbC2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbC2.Name = "actionTile_cbC2";
            this.actionTile_cbC2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbC2.TabIndex = 21;
            this.actionTile_cbC2.TabStop = false;
            // 
            // actionTile_cbC3
            // 
            this.actionTile_cbC3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbC3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbC3.Location = new System.Drawing.Point(950, 400);
            this.actionTile_cbC3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbC3.Name = "actionTile_cbC3";
            this.actionTile_cbC3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbC3.TabIndex = 22;
            this.actionTile_cbC3.TabStop = false;
            // 
            // actionTile_cbC4
            // 
            this.actionTile_cbC4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbC4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbC4.Location = new System.Drawing.Point(950, 254);
            this.actionTile_cbC4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbC4.Name = "actionTile_cbC4";
            this.actionTile_cbC4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbC4.TabIndex = 23;
            this.actionTile_cbC4.TabStop = false;
            // 
            // color_blockD
            // 
            this.color_blockD.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockD.Location = new System.Drawing.Point(262, 627);
            this.color_blockD.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockD.Name = "color_blockD";
            this.color_blockD.Size = new System.Drawing.Size(64, 62);
            this.color_blockD.TabIndex = 24;
            this.color_blockD.TabStop = false;
            // 
            // color_blockE
            // 
            this.color_blockE.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockE.Location = new System.Drawing.Point(594, 627);
            this.color_blockE.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockE.Name = "color_blockE";
            this.color_blockE.Size = new System.Drawing.Size(64, 62);
            this.color_blockE.TabIndex = 25;
            this.color_blockE.TabStop = false;
            // 
            // color_blockF
            // 
            this.color_blockF.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockF.Location = new System.Drawing.Point(950, 627);
            this.color_blockF.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockF.Name = "color_blockF";
            this.color_blockF.Size = new System.Drawing.Size(64, 62);
            this.color_blockF.TabIndex = 26;
            this.color_blockF.TabStop = false;
            // 
            // color_blockG
            // 
            this.color_blockG.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockG.Location = new System.Drawing.Point(262, 931);
            this.color_blockG.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockG.Name = "color_blockG";
            this.color_blockG.Size = new System.Drawing.Size(64, 62);
            this.color_blockG.TabIndex = 27;
            this.color_blockG.TabStop = false;
            // 
            // color_blockH
            // 
            this.color_blockH.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockH.Location = new System.Drawing.Point(594, 931);
            this.color_blockH.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockH.Name = "color_blockH";
            this.color_blockH.Size = new System.Drawing.Size(64, 62);
            this.color_blockH.TabIndex = 28;
            this.color_blockH.TabStop = false;
            // 
            // color_blockI
            // 
            this.color_blockI.BackgroundImage = global::ChevEscape.Properties.Resources.blueBlock;
            this.color_blockI.Location = new System.Drawing.Point(950, 931);
            this.color_blockI.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.color_blockI.Name = "color_blockI";
            this.color_blockI.Size = new System.Drawing.Size(64, 62);
            this.color_blockI.TabIndex = 29;
            this.color_blockI.TabStop = false;
            // 
            // actionTile_cbD1
            // 
            this.actionTile_cbD1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbD1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbD1.Location = new System.Drawing.Point(262, 700);
            this.actionTile_cbD1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbD1.Name = "actionTile_cbD1";
            this.actionTile_cbD1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbD1.TabIndex = 30;
            this.actionTile_cbD1.TabStop = false;
            // 
            // actionTile_cbD2
            // 
            this.actionTile_cbD2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbD2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbD2.Location = new System.Drawing.Point(186, 627);
            this.actionTile_cbD2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbD2.Name = "actionTile_cbD2";
            this.actionTile_cbD2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbD2.TabIndex = 31;
            this.actionTile_cbD2.TabStop = false;
            // 
            // actionTile_cbD3
            // 
            this.actionTile_cbD3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbD3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbD3.Location = new System.Drawing.Point(346, 627);
            this.actionTile_cbD3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbD3.Name = "actionTile_cbD3";
            this.actionTile_cbD3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbD3.TabIndex = 32;
            this.actionTile_cbD3.TabStop = false;
            // 
            // actionTile_cbD4
            // 
            this.actionTile_cbD4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbD4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbD4.Location = new System.Drawing.Point(262, 554);
            this.actionTile_cbD4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbD4.Name = "actionTile_cbD4";
            this.actionTile_cbD4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbD4.TabIndex = 33;
            this.actionTile_cbD4.TabStop = false;
            // 
            // actionTile_cbE1
            // 
            this.actionTile_cbE1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbE1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbE1.Location = new System.Drawing.Point(518, 627);
            this.actionTile_cbE1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbE1.Name = "actionTile_cbE1";
            this.actionTile_cbE1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbE1.TabIndex = 34;
            this.actionTile_cbE1.TabStop = false;
            // 
            // actionTile_cbE2
            // 
            this.actionTile_cbE2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbE2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbE2.Location = new System.Drawing.Point(670, 627);
            this.actionTile_cbE2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbE2.Name = "actionTile_cbE2";
            this.actionTile_cbE2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbE2.TabIndex = 35;
            this.actionTile_cbE2.TabStop = false;
            // 
            // actionTile_cbE3
            // 
            this.actionTile_cbE3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbE3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbE3.Location = new System.Drawing.Point(594, 700);
            this.actionTile_cbE3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbE3.Name = "actionTile_cbE3";
            this.actionTile_cbE3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbE3.TabIndex = 36;
            this.actionTile_cbE3.TabStop = false;
            // 
            // actionTile_cbE4
            // 
            this.actionTile_cbE4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbE4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbE4.Location = new System.Drawing.Point(594, 554);
            this.actionTile_cbE4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbE4.Name = "actionTile_cbE4";
            this.actionTile_cbE4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbE4.TabIndex = 37;
            this.actionTile_cbE4.TabStop = false;
            // 
            // actionTile_cbF1
            // 
            this.actionTile_cbF1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbF1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbF1.Location = new System.Drawing.Point(950, 554);
            this.actionTile_cbF1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbF1.Name = "actionTile_cbF1";
            this.actionTile_cbF1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbF1.TabIndex = 38;
            this.actionTile_cbF1.TabStop = false;
            // 
            // actionTile_cbF2
            // 
            this.actionTile_cbF2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbF2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbF2.Location = new System.Drawing.Point(950, 700);
            this.actionTile_cbF2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbF2.Name = "actionTile_cbF2";
            this.actionTile_cbF2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbF2.TabIndex = 39;
            this.actionTile_cbF2.TabStop = false;
            // 
            // actionTile_cbF3
            // 
            this.actionTile_cbF3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbF3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbF3.Location = new System.Drawing.Point(874, 627);
            this.actionTile_cbF3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbF3.Name = "actionTile_cbF3";
            this.actionTile_cbF3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbF3.TabIndex = 40;
            this.actionTile_cbF3.TabStop = false;
            // 
            // actionTile_cbF4
            // 
            this.actionTile_cbF4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbF4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbF4.Location = new System.Drawing.Point(1026, 627);
            this.actionTile_cbF4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbF4.Name = "actionTile_cbF4";
            this.actionTile_cbF4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbF4.TabIndex = 41;
            this.actionTile_cbF4.TabStop = false;
            // 
            // actionTile_cbG1
            // 
            this.actionTile_cbG1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbG1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbG1.Location = new System.Drawing.Point(262, 1004);
            this.actionTile_cbG1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbG1.Name = "actionTile_cbG1";
            this.actionTile_cbG1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbG1.TabIndex = 42;
            this.actionTile_cbG1.TabStop = false;
            // 
            // actionTile_cbG2
            // 
            this.actionTile_cbG2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbG2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbG2.Location = new System.Drawing.Point(186, 931);
            this.actionTile_cbG2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbG2.Name = "actionTile_cbG2";
            this.actionTile_cbG2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbG2.TabIndex = 43;
            this.actionTile_cbG2.TabStop = false;
            // 
            // actionTile_cbG3
            // 
            this.actionTile_cbG3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbG3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbG3.Location = new System.Drawing.Point(338, 931);
            this.actionTile_cbG3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbG3.Name = "actionTile_cbG3";
            this.actionTile_cbG3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbG3.TabIndex = 44;
            this.actionTile_cbG3.TabStop = false;
            // 
            // actionTile_cbG4
            // 
            this.actionTile_cbG4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbG4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbG4.Location = new System.Drawing.Point(262, 858);
            this.actionTile_cbG4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbG4.Name = "actionTile_cbG4";
            this.actionTile_cbG4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbG4.TabIndex = 45;
            this.actionTile_cbG4.TabStop = false;
            // 
            // actionTile_cbH1
            // 
            this.actionTile_cbH1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbH1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbH1.Location = new System.Drawing.Point(594, 1004);
            this.actionTile_cbH1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbH1.Name = "actionTile_cbH1";
            this.actionTile_cbH1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbH1.TabIndex = 46;
            this.actionTile_cbH1.TabStop = false;
            // 
            // actionTile_cbH2
            // 
            this.actionTile_cbH2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbH2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbH2.Location = new System.Drawing.Point(670, 931);
            this.actionTile_cbH2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbH2.Name = "actionTile_cbH2";
            this.actionTile_cbH2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbH2.TabIndex = 47;
            this.actionTile_cbH2.TabStop = false;
            // 
            // actionTile_cbH3
            // 
            this.actionTile_cbH3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbH3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbH3.Location = new System.Drawing.Point(518, 931);
            this.actionTile_cbH3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbH3.Name = "actionTile_cbH3";
            this.actionTile_cbH3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbH3.TabIndex = 48;
            this.actionTile_cbH3.TabStop = false;
            // 
            // actionTile_cbH4
            // 
            this.actionTile_cbH4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbH4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbH4.Location = new System.Drawing.Point(594, 858);
            this.actionTile_cbH4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbH4.Name = "actionTile_cbH4";
            this.actionTile_cbH4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbH4.TabIndex = 49;
            this.actionTile_cbH4.TabStop = false;
            // 
            // actionTile_cbI1
            // 
            this.actionTile_cbI1.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbI1.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbI1.Location = new System.Drawing.Point(950, 1004);
            this.actionTile_cbI1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbI1.Name = "actionTile_cbI1";
            this.actionTile_cbI1.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbI1.TabIndex = 50;
            this.actionTile_cbI1.TabStop = false;
            // 
            // actionTile_cbI2
            // 
            this.actionTile_cbI2.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbI2.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbI2.Location = new System.Drawing.Point(874, 931);
            this.actionTile_cbI2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbI2.Name = "actionTile_cbI2";
            this.actionTile_cbI2.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbI2.TabIndex = 51;
            this.actionTile_cbI2.TabStop = false;
            // 
            // actionTile_cbI3
            // 
            this.actionTile_cbI3.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbI3.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbI3.Location = new System.Drawing.Point(1026, 931);
            this.actionTile_cbI3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbI3.Name = "actionTile_cbI3";
            this.actionTile_cbI3.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbI3.TabIndex = 52;
            this.actionTile_cbI3.TabStop = false;
            // 
            // actionTile_cbI4
            // 
            this.actionTile_cbI4.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_cbI4.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_cbI4.Location = new System.Drawing.Point(950, 858);
            this.actionTile_cbI4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_cbI4.Name = "actionTile_cbI4";
            this.actionTile_cbI4.Size = new System.Drawing.Size(64, 62);
            this.actionTile_cbI4.TabIndex = 53;
            this.actionTile_cbI4.TabStop = false;
            // 
            // instructionsIcon
            // 
            this.instructionsIcon.BackColor = System.Drawing.Color.Transparent;
            this.instructionsIcon.BackgroundImage = global::ChevEscape.Properties.Resources.instructions;
            this.instructionsIcon.Location = new System.Drawing.Point(542, 37);
            this.instructionsIcon.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.instructionsIcon.Name = "instructionsIcon";
            this.instructionsIcon.Size = new System.Drawing.Size(64, 62);
            this.instructionsIcon.TabIndex = 54;
            this.instructionsIcon.TabStop = false;
            // 
            // actionTile_Instructions
            // 
            this.actionTile_Instructions.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Instructions.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Instructions.Location = new System.Drawing.Point(542, 110);
            this.actionTile_Instructions.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_Instructions.Name = "actionTile_Instructions";
            this.actionTile_Instructions.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Instructions.TabIndex = 55;
            this.actionTile_Instructions.TabStop = false;
            // 
            // door_PB
            // 
            this.door_PB.BackColor = System.Drawing.Color.Transparent;
            this.door_PB.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_PB.Location = new System.Drawing.Point(646, 37);
            this.door_PB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_PB.Name = "door_PB";
            this.door_PB.Size = new System.Drawing.Size(64, 62);
            this.door_PB.TabIndex = 56;
            this.door_PB.TabStop = false;
            // 
            // actionTile_Door
            // 
            this.actionTile_Door.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Door.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Door.Location = new System.Drawing.Point(646, 110);
            this.actionTile_Door.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_Door.Name = "actionTile_Door";
            this.actionTile_Door.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Door.TabIndex = 57;
            this.actionTile_Door.TabStop = false;
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(1128, 37);
            this.button_close.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(64, 62);
            this.button_close.TabIndex = 58;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(1052, 37);
            this.button_pause.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(64, 62);
            this.button_pause.TabIndex = 59;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // indicatorPB
            // 
            this.indicatorPB.BackColor = System.Drawing.Color.Transparent;
            this.indicatorPB.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.indicatorPB.Location = new System.Drawing.Point(388, 37);
            this.indicatorPB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.indicatorPB.Name = "indicatorPB";
            this.indicatorPB.Size = new System.Drawing.Size(64, 62);
            this.indicatorPB.TabIndex = 60;
            this.indicatorPB.TabStop = false;
            // 
            // heartContainerA
            // 
            this.heartContainerA.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerA.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerA.Location = new System.Drawing.Point(24, 254);
            this.heartContainerA.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerA.Name = "heartContainerA";
            this.heartContainerA.Size = new System.Drawing.Size(64, 62);
            this.heartContainerA.TabIndex = 61;
            this.heartContainerA.TabStop = false;
            // 
            // heartContainerC
            // 
            this.heartContainerC.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerC.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerC.Location = new System.Drawing.Point(24, 400);
            this.heartContainerC.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerC.Name = "heartContainerC";
            this.heartContainerC.Size = new System.Drawing.Size(64, 62);
            this.heartContainerC.TabIndex = 63;
            this.heartContainerC.TabStop = false;
            // 
            // heartContainerB
            // 
            this.heartContainerB.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerB.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerB.Location = new System.Drawing.Point(24, 327);
            this.heartContainerB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerB.Name = "heartContainerB";
            this.heartContainerB.Size = new System.Drawing.Size(64, 62);
            this.heartContainerB.TabIndex = 62;
            this.heartContainerB.TabStop = false;
            // 
            // button_mute
            // 
            this.button_mute.BackColor = System.Drawing.Color.Transparent;
            this.button_mute.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.button_mute.Location = new System.Drawing.Point(1128, 111);
            this.button_mute.Margin = new System.Windows.Forms.Padding(6);
            this.button_mute.Name = "button_mute";
            this.button_mute.Size = new System.Drawing.Size(64, 62);
            this.button_mute.TabIndex = 64;
            this.button_mute.TabStop = false;
            this.button_mute.Click += new System.EventHandler(this.button_mute_Click);
            // 
            // ColorPuzzle
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkGoldenrod;
            this.ClientSize = new System.Drawing.Size(1216, 1169);
            this.Controls.Add(this.button_mute);
            this.Controls.Add(this.heartContainerA);
            this.Controls.Add(this.heartContainerC);
            this.Controls.Add(this.heartContainerB);
            this.Controls.Add(this.indicatorPB);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.actionTile_Door);
            this.Controls.Add(this.door_PB);
            this.Controls.Add(this.actionTile_Instructions);
            this.Controls.Add(this.instructionsIcon);
            this.Controls.Add(this.actionTile_cbI4);
            this.Controls.Add(this.actionTile_cbI3);
            this.Controls.Add(this.actionTile_cbI2);
            this.Controls.Add(this.actionTile_cbI1);
            this.Controls.Add(this.actionTile_cbH4);
            this.Controls.Add(this.actionTile_cbH3);
            this.Controls.Add(this.actionTile_cbH2);
            this.Controls.Add(this.actionTile_cbH1);
            this.Controls.Add(this.actionTile_cbG4);
            this.Controls.Add(this.actionTile_cbG3);
            this.Controls.Add(this.actionTile_cbG2);
            this.Controls.Add(this.actionTile_cbG1);
            this.Controls.Add(this.actionTile_cbF4);
            this.Controls.Add(this.actionTile_cbF3);
            this.Controls.Add(this.actionTile_cbF2);
            this.Controls.Add(this.actionTile_cbF1);
            this.Controls.Add(this.actionTile_cbE4);
            this.Controls.Add(this.actionTile_cbE3);
            this.Controls.Add(this.actionTile_cbE2);
            this.Controls.Add(this.actionTile_cbE1);
            this.Controls.Add(this.actionTile_cbD4);
            this.Controls.Add(this.actionTile_cbD3);
            this.Controls.Add(this.actionTile_cbD2);
            this.Controls.Add(this.actionTile_cbD1);
            this.Controls.Add(this.color_blockI);
            this.Controls.Add(this.color_blockH);
            this.Controls.Add(this.color_blockG);
            this.Controls.Add(this.color_blockF);
            this.Controls.Add(this.color_blockE);
            this.Controls.Add(this.color_blockD);
            this.Controls.Add(this.actionTile_cbC4);
            this.Controls.Add(this.actionTile_cbC3);
            this.Controls.Add(this.actionTile_cbC2);
            this.Controls.Add(this.actionTile_cbC1);
            this.Controls.Add(this.color_blockC);
            this.Controls.Add(this.actionTile_cbB4);
            this.Controls.Add(this.actionTile_cbB3);
            this.Controls.Add(this.actionTile_cbB2);
            this.Controls.Add(this.actionTile_cbB1);
            this.Controls.Add(this.actionTile_cbA4);
            this.Controls.Add(this.actionTile_cbA3);
            this.Controls.Add(this.actionTile_cbA2);
            this.Controls.Add(this.color_blockB);
            this.Controls.Add(this.color_blockA);
            this.Controls.Add(this.actionTile_cbA1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.MaximumSize = new System.Drawing.Size(1216, 1169);
            this.MinimumSize = new System.Drawing.Size(1216, 1169);
            this.Name = "ColorPuzzle";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ColorPuzzle";
            this.Load += new System.EventHandler(this.ColorPuzzle_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.ColorPuzzle_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.color_blockB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbA4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbB4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbC4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockE)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockF)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockG)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockH)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.color_blockI)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbD4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbE4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbF4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbG4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbH4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_cbI4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_PB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox actionTile_cbA1;
        private System.Windows.Forms.PictureBox color_blockA;
        private System.Windows.Forms.PictureBox color_blockB;
        private System.Windows.Forms.PictureBox actionTile_cbA2;
        private System.Windows.Forms.PictureBox actionTile_cbA3;
        private System.Windows.Forms.PictureBox actionTile_cbA4;
        private System.Windows.Forms.PictureBox actionTile_cbB1;
        private System.Windows.Forms.PictureBox actionTile_cbB2;
        private System.Windows.Forms.PictureBox actionTile_cbB3;
        private System.Windows.Forms.PictureBox actionTile_cbB4;
        private System.Windows.Forms.PictureBox color_blockC;
        private System.Windows.Forms.PictureBox actionTile_cbC1;
        private System.Windows.Forms.PictureBox actionTile_cbC2;
        private System.Windows.Forms.PictureBox actionTile_cbC3;
        private System.Windows.Forms.PictureBox actionTile_cbC4;
        private System.Windows.Forms.PictureBox color_blockD;
        private System.Windows.Forms.PictureBox color_blockE;
        private System.Windows.Forms.PictureBox color_blockF;
        private System.Windows.Forms.PictureBox color_blockG;
        private System.Windows.Forms.PictureBox color_blockH;
        private System.Windows.Forms.PictureBox color_blockI;
        private System.Windows.Forms.PictureBox actionTile_cbD1;
        private System.Windows.Forms.PictureBox actionTile_cbD2;
        private System.Windows.Forms.PictureBox actionTile_cbD3;
        private System.Windows.Forms.PictureBox actionTile_cbD4;
        private System.Windows.Forms.PictureBox actionTile_cbE1;
        private System.Windows.Forms.PictureBox actionTile_cbE2;
        private System.Windows.Forms.PictureBox actionTile_cbE3;
        private System.Windows.Forms.PictureBox actionTile_cbE4;
        private System.Windows.Forms.PictureBox actionTile_cbF1;
        private System.Windows.Forms.PictureBox actionTile_cbF2;
        private System.Windows.Forms.PictureBox actionTile_cbF3;
        private System.Windows.Forms.PictureBox actionTile_cbF4;
        private System.Windows.Forms.PictureBox actionTile_cbG1;
        private System.Windows.Forms.PictureBox actionTile_cbG2;
        private System.Windows.Forms.PictureBox actionTile_cbG3;
        private System.Windows.Forms.PictureBox actionTile_cbG4;
        private System.Windows.Forms.PictureBox actionTile_cbH1;
        private System.Windows.Forms.PictureBox actionTile_cbH2;
        private System.Windows.Forms.PictureBox actionTile_cbH3;
        private System.Windows.Forms.PictureBox actionTile_cbH4;
        private System.Windows.Forms.PictureBox actionTile_cbI1;
        private System.Windows.Forms.PictureBox actionTile_cbI2;
        private System.Windows.Forms.PictureBox actionTile_cbI3;
        private System.Windows.Forms.PictureBox actionTile_cbI4;
        private System.Windows.Forms.PictureBox instructionsIcon;
        private System.Windows.Forms.PictureBox actionTile_Instructions;
        private System.Windows.Forms.PictureBox door_PB;
        private System.Windows.Forms.PictureBox actionTile_Door;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox indicatorPB;
        private System.Windows.Forms.PictureBox heartContainerA;
        private System.Windows.Forms.PictureBox heartContainerC;
        private System.Windows.Forms.PictureBox heartContainerB;
        private System.Windows.Forms.PictureBox button_mute;
    }
}