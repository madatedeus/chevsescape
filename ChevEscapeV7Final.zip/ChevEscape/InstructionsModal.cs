﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ChevEscape
{
    public partial class InstructionsModal : Form
    {
        public InstructionsModal()
        {
            InitializeComponent();
        }


        private void ModalCloseBtn_Click(object sender, EventArgs e)
        {
            this.Hide();
        } // close button modal

        private void InstructionsModal_Load(object sender, EventArgs e)
        {
            
        }

        public void prepareModal(string instructions)
        {
            text_instructions.Text = instructions;
        }
    } // InstructionsModal class
}
