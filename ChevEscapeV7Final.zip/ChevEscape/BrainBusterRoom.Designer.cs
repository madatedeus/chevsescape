﻿namespace ChevEscape
{
    partial class BrainBusterRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.main_player = new System.Windows.Forms.PictureBox();
            this.pauseButton = new System.Windows.Forms.PictureBox();
            this.closeButton = new System.Windows.Forms.PictureBox();
            this.heartContainerC = new System.Windows.Forms.PictureBox();
            this.heartContainerB = new System.Windows.Forms.PictureBox();
            this.heartContainerA = new System.Windows.Forms.PictureBox();
            this.actionTile_Game = new System.Windows.Forms.PictureBox();
            this.movePanel = new System.Windows.Forms.PictureBox();
            this.gatePanel3 = new System.Windows.Forms.PictureBox();
            this.gatePanel1 = new System.Windows.Forms.PictureBox();
            this.runningPanel = new System.Windows.Forms.PictureBox();
            this.wrongPanel = new System.Windows.Forms.PictureBox();
            this.actionTile_instructions = new System.Windows.Forms.PictureBox();
            this.actionTile_door = new System.Windows.Forms.PictureBox();
            this.gatePanel4 = new System.Windows.Forms.PictureBox();
            this.gatePanel2 = new System.Windows.Forms.PictureBox();
            this.waitingForInput = new System.Windows.Forms.PictureBox();
            this.correctPanel = new System.Windows.Forms.PictureBox();
            this.instructionsIcon = new System.Windows.Forms.PictureBox();
            this.door_A = new System.Windows.Forms.PictureBox();
            this.indicatorBb = new System.Windows.Forms.PictureBox();
            this.muteButton = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pauseButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeButton)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Game)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.movePanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.runningPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.waitingForInput)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.correctPanel)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorBb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.muteButton)).BeginInit();
            this.SuspendLayout();
            // 
            // main_player
            // 
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_walkingRight;
            this.main_player.Location = new System.Drawing.Point(1128, 1085);
            this.main_player.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(64, 62);
            this.main_player.TabIndex = 54;
            this.main_player.TabStop = false;
            // 
            // pauseButton
            // 
            this.pauseButton.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.pauseButton.Location = new System.Drawing.Point(1052, 23);
            this.pauseButton.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.pauseButton.Name = "pauseButton";
            this.pauseButton.Size = new System.Drawing.Size(64, 62);
            this.pauseButton.TabIndex = 67;
            this.pauseButton.TabStop = false;
            this.pauseButton.Click += new System.EventHandler(this.pauseButton_Click);
            // 
            // closeButton
            // 
            this.closeButton.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.closeButton.Location = new System.Drawing.Point(1128, 23);
            this.closeButton.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.closeButton.Name = "closeButton";
            this.closeButton.Size = new System.Drawing.Size(64, 62);
            this.closeButton.TabIndex = 66;
            this.closeButton.TabStop = false;
            this.closeButton.Click += new System.EventHandler(this.closeButton_Click);
            // 
            // heartContainerC
            // 
            this.heartContainerC.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerC.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerC.Location = new System.Drawing.Point(1128, 865);
            this.heartContainerC.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerC.Name = "heartContainerC";
            this.heartContainerC.Size = new System.Drawing.Size(64, 62);
            this.heartContainerC.TabIndex = 72;
            this.heartContainerC.TabStop = false;
            // 
            // heartContainerB
            // 
            this.heartContainerB.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerB.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerB.Location = new System.Drawing.Point(1128, 938);
            this.heartContainerB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerB.Name = "heartContainerB";
            this.heartContainerB.Size = new System.Drawing.Size(64, 62);
            this.heartContainerB.TabIndex = 71;
            this.heartContainerB.TabStop = false;
            // 
            // heartContainerA
            // 
            this.heartContainerA.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerA.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerA.Location = new System.Drawing.Point(1128, 1012);
            this.heartContainerA.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.heartContainerA.Name = "heartContainerA";
            this.heartContainerA.Size = new System.Drawing.Size(64, 62);
            this.heartContainerA.TabIndex = 70;
            this.heartContainerA.TabStop = false;
            // 
            // actionTile_Game
            // 
            this.actionTile_Game.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Game.Location = new System.Drawing.Point(24, 765);
            this.actionTile_Game.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_Game.Name = "actionTile_Game";
            this.actionTile_Game.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Game.TabIndex = 69;
            this.actionTile_Game.TabStop = false;
            // 
            // movePanel
            // 
            this.movePanel.BackgroundImage = global::ChevEscape.Properties.Resources.bbBlank;
            this.movePanel.Location = new System.Drawing.Point(24, 838);
            this.movePanel.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.movePanel.Name = "movePanel";
            this.movePanel.Size = new System.Drawing.Size(320, 308);
            this.movePanel.TabIndex = 65;
            this.movePanel.TabStop = false;
            // 
            // gatePanel3
            // 
            this.gatePanel3.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.gatePanel3.Location = new System.Drawing.Point(508, 1012);
            this.gatePanel3.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gatePanel3.Name = "gatePanel3";
            this.gatePanel3.Size = new System.Drawing.Size(64, 62);
            this.gatePanel3.TabIndex = 63;
            this.gatePanel3.TabStop = false;
            this.gatePanel3.Visible = false;
            // 
            // gatePanel1
            // 
            this.gatePanel1.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.gatePanel1.Location = new System.Drawing.Point(584, 1012);
            this.gatePanel1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gatePanel1.Name = "gatePanel1";
            this.gatePanel1.Size = new System.Drawing.Size(64, 62);
            this.gatePanel1.TabIndex = 61;
            this.gatePanel1.TabStop = false;
            this.gatePanel1.Visible = false;
            // 
            // runningPanel
            // 
            this.runningPanel.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.runningPanel.Location = new System.Drawing.Point(736, 1012);
            this.runningPanel.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.runningPanel.Name = "runningPanel";
            this.runningPanel.Size = new System.Drawing.Size(64, 62);
            this.runningPanel.TabIndex = 59;
            this.runningPanel.TabStop = false;
            // 
            // wrongPanel
            // 
            this.wrongPanel.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.wrongPanel.Location = new System.Drawing.Point(812, 1012);
            this.wrongPanel.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.wrongPanel.Name = "wrongPanel";
            this.wrongPanel.Size = new System.Drawing.Size(64, 62);
            this.wrongPanel.TabIndex = 58;
            this.wrongPanel.TabStop = false;
            // 
            // actionTile_instructions
            // 
            this.actionTile_instructions.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_instructions.Location = new System.Drawing.Point(962, 1012);
            this.actionTile_instructions.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_instructions.Name = "actionTile_instructions";
            this.actionTile_instructions.Size = new System.Drawing.Size(64, 62);
            this.actionTile_instructions.TabIndex = 56;
            this.actionTile_instructions.TabStop = false;
            // 
            // actionTile_door
            // 
            this.actionTile_door.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_door.Location = new System.Drawing.Point(1038, 1012);
            this.actionTile_door.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.actionTile_door.Name = "actionTile_door";
            this.actionTile_door.Size = new System.Drawing.Size(64, 62);
            this.actionTile_door.TabIndex = 53;
            this.actionTile_door.TabStop = false;
            // 
            // gatePanel4
            // 
            this.gatePanel4.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.gatePanel4.Location = new System.Drawing.Point(508, 1085);
            this.gatePanel4.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gatePanel4.Name = "gatePanel4";
            this.gatePanel4.Size = new System.Drawing.Size(64, 62);
            this.gatePanel4.TabIndex = 64;
            this.gatePanel4.TabStop = false;
            this.gatePanel4.Visible = false;
            // 
            // gatePanel2
            // 
            this.gatePanel2.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.gatePanel2.Location = new System.Drawing.Point(584, 1085);
            this.gatePanel2.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.gatePanel2.Name = "gatePanel2";
            this.gatePanel2.Size = new System.Drawing.Size(64, 62);
            this.gatePanel2.TabIndex = 62;
            this.gatePanel2.TabStop = false;
            this.gatePanel2.Visible = false;
            // 
            // waitingForInput
            // 
            this.waitingForInput.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.waitingForInput.Location = new System.Drawing.Point(736, 1085);
            this.waitingForInput.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.waitingForInput.Name = "waitingForInput";
            this.waitingForInput.Size = new System.Drawing.Size(64, 62);
            this.waitingForInput.TabIndex = 60;
            this.waitingForInput.TabStop = false;
            // 
            // correctPanel
            // 
            this.correctPanel.Image = global::ChevEscape.Properties.Resources.panel_neutral;
            this.correctPanel.Location = new System.Drawing.Point(812, 1085);
            this.correctPanel.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.correctPanel.Name = "correctPanel";
            this.correctPanel.Size = new System.Drawing.Size(64, 62);
            this.correctPanel.TabIndex = 57;
            this.correctPanel.TabStop = false;
            // 
            // instructionsIcon
            // 
            this.instructionsIcon.Image = global::ChevEscape.Properties.Resources.instructions;
            this.instructionsIcon.Location = new System.Drawing.Point(962, 1085);
            this.instructionsIcon.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.instructionsIcon.Name = "instructionsIcon";
            this.instructionsIcon.Size = new System.Drawing.Size(64, 62);
            this.instructionsIcon.TabIndex = 55;
            this.instructionsIcon.TabStop = false;
            // 
            // door_A
            // 
            this.door_A.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_A.Location = new System.Drawing.Point(1038, 1085);
            this.door_A.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.door_A.Name = "door_A";
            this.door_A.Size = new System.Drawing.Size(64, 62);
            this.door_A.TabIndex = 52;
            this.door_A.TabStop = false;
            // 
            // indicatorBb
            // 
            this.indicatorBb.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.indicatorBb.Location = new System.Drawing.Point(1128, 765);
            this.indicatorBb.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.indicatorBb.Name = "indicatorBb";
            this.indicatorBb.Size = new System.Drawing.Size(64, 62);
            this.indicatorBb.TabIndex = 73;
            this.indicatorBb.TabStop = false;
            // 
            // muteButton
            // 
            this.muteButton.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.muteButton.Location = new System.Drawing.Point(1128, 97);
            this.muteButton.Margin = new System.Windows.Forms.Padding(6);
            this.muteButton.Name = "muteButton";
            this.muteButton.Size = new System.Drawing.Size(64, 62);
            this.muteButton.TabIndex = 74;
            this.muteButton.TabStop = false;
            this.muteButton.Click += new System.EventHandler(this.muteButton_Click);
            // 
            // BrainBusterRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::ChevEscape.Properties.Resources.greenBackground;
            this.ClientSize = new System.Drawing.Size(1216, 1169);
            this.Controls.Add(this.muteButton);
            this.Controls.Add(this.indicatorBb);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.pauseButton);
            this.Controls.Add(this.closeButton);
            this.Controls.Add(this.heartContainerC);
            this.Controls.Add(this.heartContainerB);
            this.Controls.Add(this.heartContainerA);
            this.Controls.Add(this.actionTile_Game);
            this.Controls.Add(this.movePanel);
            this.Controls.Add(this.gatePanel3);
            this.Controls.Add(this.gatePanel1);
            this.Controls.Add(this.runningPanel);
            this.Controls.Add(this.wrongPanel);
            this.Controls.Add(this.actionTile_instructions);
            this.Controls.Add(this.actionTile_door);
            this.Controls.Add(this.gatePanel4);
            this.Controls.Add(this.gatePanel2);
            this.Controls.Add(this.waitingForInput);
            this.Controls.Add(this.correctPanel);
            this.Controls.Add(this.instructionsIcon);
            this.Controls.Add(this.door_A);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "BrainBusterRoom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "BrainBusterRoom";
            this.Load += new System.EventHandler(this.BrainBusterRoom_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.BrainBusterRoom_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pauseButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.closeButton)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Game)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.movePanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.runningPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wrongPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gatePanel2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.waitingForInput)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.correctPanel)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorBb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.muteButton)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox pauseButton;
        private System.Windows.Forms.PictureBox closeButton;
        private System.Windows.Forms.PictureBox heartContainerC;
        private System.Windows.Forms.PictureBox heartContainerB;
        private System.Windows.Forms.PictureBox heartContainerA;
        private System.Windows.Forms.PictureBox actionTile_Game;
        private System.Windows.Forms.PictureBox movePanel;
        private System.Windows.Forms.PictureBox gatePanel3;
        private System.Windows.Forms.PictureBox gatePanel1;
        private System.Windows.Forms.PictureBox runningPanel;
        private System.Windows.Forms.PictureBox wrongPanel;
        private System.Windows.Forms.PictureBox actionTile_instructions;
        private System.Windows.Forms.PictureBox actionTile_door;
        private System.Windows.Forms.PictureBox gatePanel4;
        private System.Windows.Forms.PictureBox gatePanel2;
        private System.Windows.Forms.PictureBox waitingForInput;
        private System.Windows.Forms.PictureBox correctPanel;
        private System.Windows.Forms.PictureBox instructionsIcon;
        private System.Windows.Forms.PictureBox door_A;
        private System.Windows.Forms.PictureBox indicatorBb;
        private System.Windows.Forms.PictureBox muteButton;
    }
}