﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class ImageScrambler : Form
    {
        int SliceIndex = 0;//Null image index.
        List<Bitmap> OriginalPictureList = new List<Bitmap>();//Bitmap for the the orignal image fore refence to check if puzzle is completed.
        System.Diagnostics.Stopwatch timer = new System.Diagnostics.Stopwatch();

        public ImageScrambler()
        {
            InitializeComponent();
            OriginalPictureList.AddRange(new Bitmap[] { Properties.Resources.img9, Properties.Resources.img8, Properties.Resources.img7, Properties.Resources.img6, Properties.Resources.img5, Properties.Resources.img4, Properties.Resources.img3, Properties.Resources.img2, Properties.Resources.img1, Properties.Resources.ImageNull });
            lblTimer.Text = "00:00:00";
        }

        private void ImageScrambler_Load(object sender, EventArgs e)
        {
            ShuffleImage();//Call function ShuffleImage when form is loaded all the time. 
        }

        void ShuffleImage()
        {
            do
            {
                int a;
                List<int> Indexes = new List<int>(new int[] { 0, 1, 2, 3, 4, 5, 6, 7, 9 });// Did not add slice # eight as we do not need it since we have the null slice
                Random value = new Random();
                for (int i = 0; i < 9; i++)
                {
                    Indexes.Remove((a = Indexes[value.Next(0, Indexes.Count)]));
                    ((PictureBox)gbImageScramble.Controls[i]).Image = OriginalPictureList[a];
                    if (a == 9) SliceIndex = i;//storage for emtpy box image.
                }
            } while (CheckWin());
        }

        private void btnShuffle_Click(object sender, EventArgs e)
        {
            DialogResult Shuffle = new DialogResult();
            if (lblTimer.Text != "00:00:00")
            {
                Shuffle = MessageBox.Show("Are You Sure You Want To Restart?", "Image Scramble", MessageBoxButtons.YesNo, MessageBoxIcon.Question);//Restart prompt
            }
            if (Shuffle == DialogResult.Yes || lblTimer.Text == "00:00:00")
            {
                ShuffleImage();
                timer.Reset();
                lblTimer.Text = "00:00:00";
            }
        }

        private void Quit(object sender, FormClosingEventArgs e)
        {
            DialogResult Exit = MessageBox.Show("Are You Sure To Exit the Puzzle?", "ImageScramble", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (sender as Button != btnExit && Exit == DialogResult.No) e.Cancel = true;
            if (sender as Button == btnExit && Exit == DialogResult.Yes) this.Close();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Quit(sender, e as FormClosingEventArgs);
        }

        private void SwitchPictureBox(object sender, EventArgs e)
        {
            if (lblTimer.Text == "00:00:00")
                timer.Start();
            int PBIndex = gbImageScramble.Controls.IndexOf(sender as Control);
            if (SliceIndex != PBIndex)
            {
                List<int> Neighbors = new List<int>(new int[] { ((PBIndex % 3 == 0) ? -1 : PBIndex - 1), PBIndex - 3, (PBIndex % 3 == 2) ? -1 : PBIndex + 1, PBIndex + 3 });
                if (Neighbors.Contains(SliceIndex))
                {
                    ((PictureBox)gbImageScramble.Controls[SliceIndex]).Image = ((PictureBox)gbImageScramble.Controls[PBIndex]).Image;
                    ((PictureBox)gbImageScramble.Controls[PBIndex]).Image = OriginalPictureList[9];
                    SliceIndex = PBIndex;

                    // Play sound effect
                    Program.gameManager.sfxPlay(Properties.Resources.Spark);
                    if (CheckWin())
                    {
                        timer.Stop();
                        (gbImageScramble.Controls[8] as PictureBox).Image = OriginalPictureList[8];
                        MessageBox.Show("Congratulations, you won!\nTime Elapsed: " + timer.Elapsed.ToString().Remove(8), "Image Scramble");

                        // Play sound effect
                        Program.gameManager.sfxPlay(Properties.Resources.PuzzleComplete);

                        // Update main room
                        Program.gameManager.setPuzzleCompletionStatus(ImageRoom.IMAGEPUZZLE_ID, true);
                        
                    }
                }
            }
        }

        public bool CheckWin()
        {
            int i;
            for (i = 0; i < 8; i++)
            {
                if ((gbImageScramble.Controls[i] as PictureBox).Image != OriginalPictureList[i]) break;//Conditon for checking Picture Box is the same as the OrignalPictureList
            }
            if (i == 8) return true;
            else return false;
        }

        private void UpdateTimer(object sender, EventArgs e)
        {
            if (timer.Elapsed.ToString() != "00:00:00")
                lblTimer.Text = timer.Elapsed.ToString().Remove(8);
            if (timer.Elapsed.ToString() == "00:00:00")
                btnPause.Enabled = false;
            else
                btnPause.Enabled = true;
            if (timer.Elapsed.Minutes.ToString() == "3")
            {
                timer.Reset();
                lblTimer.Text = "00:00:00";
                btnPause.Enabled = false;
                Program.gameManager.decrementAttempts(); // Decrement attempts for failed puzzle
                MessageBox.Show("Time Is Up\nTry Again", "Image Scramble");
                ShuffleImage();
            }
        }

        private void Resume(object sender, EventArgs e)
        {
            if (btnPause.Text == "Pause")
            {
                timer.Stop();
                gbImageScramble.Visible = false;
                btnPause.Text = "Resume";
            }
            else
            {
                timer.Start();
                gbImageScramble.Visible = true;
                btnPause.Text = "Pause";
            }
        }
    }
}
