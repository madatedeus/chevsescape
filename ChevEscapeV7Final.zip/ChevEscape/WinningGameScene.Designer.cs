﻿namespace ChevEscape
{
    partial class WinningGameScene
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.PlayAgain = new System.Windows.Forms.Button();
            this.EndGame = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            this.SuspendLayout();
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(521, 12);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(32, 32);
            this.button_pause.TabIndex = 45;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(559, 12);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(32, 32);
            this.button_close.TabIndex = 44;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.DarkGray;
            this.label1.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(45, 73);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(508, 64);
            this.label1.TabIndex = 46;
            this.label1.Text = "CONGRATULATIONS";
            this.label1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.DarkGray;
            this.label2.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(198, 150);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(188, 64);
            this.label2.TabIndex = 47;
            this.label2.Text = "CHEV!";
            this.label2.Click += new System.EventHandler(this.Label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.DarkGray;
            this.label3.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(237, 262);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(124, 64);
            this.label3.TabIndex = 48;
            this.label3.Text = "YOU";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.DarkGray;
            this.label4.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(97, 326);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(412, 64);
            this.label4.TabIndex = 49;
            this.label4.Text = "SUCCESSFULLY";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.DarkGray;
            this.label5.Font = new System.Drawing.Font("MS Gothic", 48F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(176, 390);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(284, 64);
            this.label5.TabIndex = 50;
            this.label5.Text = "ESCAPED!";
            // 
            // PlayAgain
            // 
            this.PlayAgain.BackColor = System.Drawing.Color.LightGreen;
            this.PlayAgain.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlayAgain.Location = new System.Drawing.Point(88, 503);
            this.PlayAgain.Name = "PlayAgain";
            this.PlayAgain.Size = new System.Drawing.Size(164, 72);
            this.PlayAgain.TabIndex = 51;
            this.PlayAgain.Text = "Play Again";
            this.PlayAgain.UseVisualStyleBackColor = false;
            this.PlayAgain.Click += new System.EventHandler(this.PlayAgain_Click);
            // 
            // EndGame
            // 
            this.EndGame.BackColor = System.Drawing.Color.IndianRed;
            this.EndGame.Font = new System.Drawing.Font("MS Gothic", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EndGame.Location = new System.Drawing.Point(335, 503);
            this.EndGame.Name = "EndGame";
            this.EndGame.Size = new System.Drawing.Size(164, 72);
            this.EndGame.TabIndex = 52;
            this.EndGame.Text = "End Game";
            this.EndGame.UseVisualStyleBackColor = false;
            this.EndGame.Click += new System.EventHandler(this.EndGame_Click);
            // 
            // WinningGameScene
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(608, 608);
            this.Controls.Add(this.EndGame);
            this.Controls.Add(this.PlayAgain);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.button_close);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(608, 608);
            this.MinimumSize = new System.Drawing.Size(608, 608);
            this.Name = "WinningGameScene";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "WinningGameScene";
            this.Load += new System.EventHandler(this.WinningGameScene_Load);
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button PlayAgain;
        private System.Windows.Forms.Button EndGame;
    }
}