﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GameUtilities;

namespace ChevEscape
{
    public partial class MainRoom : Form
    {
        GameGrid map = new GameGrid();
        Player player;
        Form memory_room = new MemoryRoom();
        ColorPuzzle color_room = new ColorPuzzle();
        ImageRoom image_room = new ImageRoom();
        BrainBusterRoom brainBuster_room = new BrainBusterRoom();

        HeartContainer heartA;
        HeartContainer heartB;
        HeartContainer heartC;

        MainRoomManager mainRoomManager;

        CloseButton closeButton;
        PauseButton pauseButton;
        MuteButton muteButton;

        public const int roomID = 0;


        public MainRoom()
        {
            InitializeComponent();
        }

        private void MainRoom_Load(object sender, EventArgs e)
        {
            InitializeGameComponents();
            Program.gameManager.updatePlayersHeartContainer(heartA, heartB, heartC);
            muteButton.updateIcon();
        }

        private void InitializeGameComponents()
        {
            int playerPos_column = Program.gameManager.getPlayerSavedPosition_column();
            int playerPos_row = Program.gameManager.getPlayerSavedPosition_row();
            player = new Player(map, main_player, playerPos_row , playerPos_column);
            closeButton = new CloseButton(button_close);
            pauseButton = new PauseButton(this, button_pause);
            muteButton = new MuteButton(button_mute);
            // set the assets onto the map

            // Setting heart container on screen
            heartA = new HeartContainer(1, heartContainerA);
            heartB = new HeartContainer(2, heartContainerB);
            heartC = new HeartContainer(3, heartContainerC);

            // Door A - Memory room
            Door doorA = new Door(this, memory_room, map, door_A, 2, 9);
            ActionTile actionTileA = new ActionTile(doorA, map, actionTile_A, 3, 9);


            // Door B - Image Srambler
            door_B.Image.RotateFlip(RotateFlipType.Rotate90FlipX);
            actionTile_B.Image.RotateFlip(RotateFlipType.Rotate90FlipX);

            Door doorB = new Door(this, image_room, map, door_B, 9, 2);
            ActionTile actionTileB = new ActionTile(doorB, map, actionTile_B, 9, 3);

            // Door C - Color Puzzle
            door_C.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);
            actionTile_C.Image.RotateFlip(RotateFlipType.Rotate180FlipNone);

            Door doorC = new Door(this, color_room, map, door_C, 15, 9);
            ActionTile actionTileC = new ActionTile(doorC, map, actionTile_C, 14, 9);

            // Door D - Brain Buster Puzzle
            door_D.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);
            actionTile_D.Image.RotateFlip(RotateFlipType.Rotate90FlipNone);

            Door doorD = new Door(this, brainBuster_room, map, door_D, 9, 15);
            ActionTile actionTileD = new ActionTile(doorD, map, actionTile_D, 9, 14);


            // Exit Door
            WinningGameScene winScene = new WinningGameScene();
            LockedDoor exitDoor = new LockedDoor(this, winScene, map, door_exit, 1, 2);
            ActionTile actionTileExitDoor = new ActionTile(exitDoor, map, actionTile_exitDoor, 2, 2);
            Indicator indicatorA = new Indicator(map, puzzleIndicator_A, 0, 0);
            Indicator indicatorB = new Indicator(map, puzzleIndicator_B, 0, 1);
            Indicator indicatorC = new Indicator(map, puzzleIndicator_C, 0, 3);
            Indicator indicatorD = new Indicator(map, puzzleIndicator_D, 0, 4);

            Instructions instructions = new Instructions(roomID, map, instructionsIcon, 8, 9);
            ActionTile instructionsAT = new ActionTile(instructions, map, actionTile_instructions, 9, 9);

            map.addToGrid(doorA);
            map.addToGrid(doorB);
            map.addToGrid(doorC);
            map.addToGrid(doorD);

            map.addToGrid(actionTileA);
            map.addToGrid(actionTileB);
            map.addToGrid(actionTileC);
            map.addToGrid(actionTileD);

            map.addToGrid(exitDoor);
            map.addToGrid(actionTileExitDoor);
            map.addToGrid(indicatorA);
            map.addToGrid(indicatorB);
            map.addToGrid(indicatorC);
            map.addToGrid(indicatorD);
            map.addToGrid(instructions);
            map.addToGrid(instructionsAT);
            mainRoomManager = new MainRoomManager(exitDoor, indicatorA, indicatorB, indicatorC, indicatorD);

            mainRoomManager.UpdateCompletedPuzzleIndicators();

        }

        private void MainRoom_KeyUp(object sender, KeyEventArgs e)
        {
            Program.gameManager.CheckIfGameIsOver(this);
            if (e.KeyValue == player.getControls_ActionKeyValue())
            {
                Program.gameManager.setPlayerSavedPosition(player.getPlayerCurrentPosition_Row(), player.getPlayerCurrentPosition_Column());
            }
            player.Move(e.KeyValue);
        }

        private void MainRoom_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void Button_close_Click(object sender, EventArgs e)
        {
            closeButton.EndGame();
        }

        private void Button_pause_Click(object sender, EventArgs e)
        {
            pauseButton.PauseGame();
        }

        private void button_mute_Click(object sender, EventArgs e)
        {
            muteButton.toggleSound();
        }

        private void PuzzleIndicator_A_Click(object sender, EventArgs e)
        {
            // Implemented for testing purposes - cheat cheat UNLOCKS ALL DOORS
            Program.gameManager.setPuzzleCompletionStatus(1, true);
            Program.gameManager.setPuzzleCompletionStatus(2, true);
            Program.gameManager.setPuzzleCompletionStatus(3, true);
            Program.gameManager.setPuzzleCompletionStatus(4, true);
            mainRoomManager.UpdateCompletedPuzzleIndicators();

        }
    } // Main Room form

    public class MainRoomManager
    {
        public MainRoomManager(Door exit_door, Indicator puzzleAIndc, Indicator puzzleBIndc, Indicator puzzleCIndc, Indicator puzzleDIndc)
        {
            exitDoor = exit_door;
            
            puzzleA_indc = puzzleAIndc;
            puzzleB_indc = puzzleBIndc;
            puzzleC_indc = puzzleCIndc;
            puzzleD_indc = puzzleDIndc;

        }

        const int MEMORYPUZZLE_ID = 1;
        const int IMAGESCRAMBLER_ID = 2;
        const int COLORPUZZLE_ID = 3;
        const int BRAINBUSTERPUZZLE_ID = 4;

        Door exitDoor;
        Indicator puzzleA_indc;
        Indicator puzzleB_indc;
        Indicator puzzleC_indc;
        Indicator puzzleD_indc;

        ExitDoorLock lockA = new ExitDoorLock(MEMORYPUZZLE_ID);
        ExitDoorLock lockB = new ExitDoorLock(IMAGESCRAMBLER_ID);
        ExitDoorLock lockC = new ExitDoorLock(COLORPUZZLE_ID);
        ExitDoorLock lockD = new ExitDoorLock(BRAINBUSTERPUZZLE_ID);


        public struct ExitDoorLock
        {
            public ExitDoorLock(int puzzle_Id)
            {
                puzzleID = puzzle_Id;
                isUnlocked = false;
            } // ExitDoorLock struct

            int puzzleID;
            bool isUnlocked;

            public void setLock(bool unlock)
            {
                isUnlocked = unlock;
            } //set lock
        } // Exit Door Lock



        

        public void UpdateCompletedPuzzleIndicators()
        {
            // Puzzle A - Memory Puzzle
            if (Program.gameManager.getPuzzleCompletionStatus(MEMORYPUZZLE_ID))
            {
                puzzleA_indc.showCorrectState();
                lockA.setLock(true);

            }
            else
            {
                puzzleA_indc.showNeutralState();
                lockA.setLock(false);
            }

            // Puzzle B - Image Scrambler
            if (Program.gameManager.getPuzzleCompletionStatus(IMAGESCRAMBLER_ID))
            {
                puzzleB_indc.showCorrectState();
                lockB.setLock(true);
            }
            else
            {
                puzzleB_indc.showNeutralState();
                lockB.setLock(false);
            }

            //Puzzle C - Color Puzz
            if (Program.gameManager.getPuzzleCompletionStatus(COLORPUZZLE_ID))
            {
                puzzleC_indc.showCorrectState();
                lockC.setLock(true);
            }
            else
            {
                puzzleC_indc.showNeutralState();
                lockC.setLock(false);
            }

            // Puzzle D - Brain Buster
            if (Program.gameManager.getPuzzleCompletionStatus(BRAINBUSTERPUZZLE_ID))
            {
                puzzleD_indc.showCorrectState();
                lockD.setLock(true);
            }
            else
            {
                puzzleD_indc.showNeutralState();
                lockD.setLock(false);
            }
        } // UpdateCompletedPuzzleIndicators

    } // main room manager
}
