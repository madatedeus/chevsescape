﻿namespace ChevEscape
{
    partial class InstructionsModal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.text_instructions = new System.Windows.Forms.TextBox();
            this.modalCloseBtn = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.modalCloseBtn)).BeginInit();
            this.SuspendLayout();
            // 
            // text_instructions
            // 
            this.text_instructions.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.text_instructions.Location = new System.Drawing.Point(12, 70);
            this.text_instructions.MaximumSize = new System.Drawing.Size(280, 180);
            this.text_instructions.MinimumSize = new System.Drawing.Size(280, 180);
            this.text_instructions.Multiline = true;
            this.text_instructions.Name = "text_instructions";
            this.text_instructions.ReadOnly = true;
            this.text_instructions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.text_instructions.Size = new System.Drawing.Size(280, 180);
            this.text_instructions.TabIndex = 1;
            this.text_instructions.TabStop = false;
            // 
            // modalCloseBtn
            // 
            this.modalCloseBtn.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.modalCloseBtn.Location = new System.Drawing.Point(260, 10);
            this.modalCloseBtn.Name = "modalCloseBtn";
            this.modalCloseBtn.Size = new System.Drawing.Size(32, 32);
            this.modalCloseBtn.TabIndex = 0;
            this.modalCloseBtn.TabStop = false;
            this.modalCloseBtn.Click += new System.EventHandler(this.ModalCloseBtn_Click);
            // 
            // InstructionsModal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 11F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.BackgroundImage = global::ChevEscape.Properties.Resources.modalDesignAs;
            this.ClientSize = new System.Drawing.Size(304, 304);
            this.Controls.Add(this.text_instructions);
            this.Controls.Add(this.modalCloseBtn);
            this.Font = new System.Drawing.Font("MS Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MaximumSize = new System.Drawing.Size(304, 304);
            this.MinimumSize = new System.Drawing.Size(304, 304);
            this.Name = "InstructionsModal";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "InstructionsModal";
            this.Load += new System.EventHandler(this.InstructionsModal_Load);
            ((System.ComponentModel.ISupportInitialize)(this.modalCloseBtn)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox modalCloseBtn;
        private System.Windows.Forms.TextBox text_instructions;
    }
}