﻿namespace ChevEscape
{
    partial class MemoryRoom
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button_pause = new System.Windows.Forms.PictureBox();
            this.button_close = new System.Windows.Forms.PictureBox();
            this.main_player = new System.Windows.Forms.PictureBox();
            this.actionTile_Instructions = new System.Windows.Forms.PictureBox();
            this.instructionsIcon = new System.Windows.Forms.PictureBox();
            this.progressBar_PB = new System.Windows.Forms.PictureBox();
            this.actionTile_submitSwitch = new System.Windows.Forms.PictureBox();
            this.switch_submit = new System.Windows.Forms.PictureBox();
            this.switch_beginPuzzle = new System.Windows.Forms.PictureBox();
            this.actionTile_beginSwitch = new System.Windows.Forms.PictureBox();
            this.flashBin_Yellow = new System.Windows.Forms.PictureBox();
            this.switch_yellowBin = new System.Windows.Forms.PictureBox();
            this.actionTile_yellowSwitch = new System.Windows.Forms.PictureBox();
            this.flashBin_Green = new System.Windows.Forms.PictureBox();
            this.switch_greenBin = new System.Windows.Forms.PictureBox();
            this.actionTile_greenSwitch = new System.Windows.Forms.PictureBox();
            this.flashBin_Red = new System.Windows.Forms.PictureBox();
            this.switch_redBin = new System.Windows.Forms.PictureBox();
            this.actionTile_redSwitch = new System.Windows.Forms.PictureBox();
            this.flashBin_Blue = new System.Windows.Forms.PictureBox();
            this.switch_blueBin = new System.Windows.Forms.PictureBox();
            this.actionTile_blueSwitch = new System.Windows.Forms.PictureBox();
            this.indicatorPB = new System.Windows.Forms.PictureBox();
            this.actionTile_Door = new System.Windows.Forms.PictureBox();
            this.door_A = new System.Windows.Forms.PictureBox();
            this.heartContainerA = new System.Windows.Forms.PictureBox();
            this.heartContainerC = new System.Windows.Forms.PictureBox();
            this.heartContainerB = new System.Windows.Forms.PictureBox();
            this.button_mute = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressBar_PB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_submitSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_submit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_beginPuzzle)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_beginSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Yellow)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_yellowBin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_yellowSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Green)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_greenBin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_greenSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Red)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_redBin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_redSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Blue)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_blueBin)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_blueSwitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorPB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).BeginInit();
            this.SuspendLayout();
            // 
            // button_pause
            // 
            this.button_pause.BackColor = System.Drawing.Color.Transparent;
            this.button_pause.Image = global::ChevEscape.Properties.Resources.pauseButton;
            this.button_pause.Location = new System.Drawing.Point(1052, 23);
            this.button_pause.Margin = new System.Windows.Forms.Padding(6);
            this.button_pause.Name = "button_pause";
            this.button_pause.Size = new System.Drawing.Size(64, 62);
            this.button_pause.TabIndex = 43;
            this.button_pause.TabStop = false;
            this.button_pause.Click += new System.EventHandler(this.Button_pause_Click);
            // 
            // button_close
            // 
            this.button_close.BackColor = System.Drawing.Color.Transparent;
            this.button_close.Image = global::ChevEscape.Properties.Resources.closeButton;
            this.button_close.Location = new System.Drawing.Point(1128, 23);
            this.button_close.Margin = new System.Windows.Forms.Padding(6);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(64, 62);
            this.button_close.TabIndex = 42;
            this.button_close.TabStop = false;
            this.button_close.Click += new System.EventHandler(this.Button_close_Click);
            // 
            // main_player
            // 
            this.main_player.BackColor = System.Drawing.Color.Transparent;
            this.main_player.Image = global::ChevEscape.Properties.Resources.chev_walkingUp;
            this.main_player.Location = new System.Drawing.Point(1128, 1065);
            this.main_player.Margin = new System.Windows.Forms.Padding(6);
            this.main_player.Name = "main_player";
            this.main_player.Size = new System.Drawing.Size(64, 62);
            this.main_player.TabIndex = 2;
            this.main_player.TabStop = false;
            // 
            // actionTile_Instructions
            // 
            this.actionTile_Instructions.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Instructions.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Instructions.Location = new System.Drawing.Point(310, 973);
            this.actionTile_Instructions.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_Instructions.Name = "actionTile_Instructions";
            this.actionTile_Instructions.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Instructions.TabIndex = 46;
            this.actionTile_Instructions.TabStop = false;
            // 
            // instructionsIcon
            // 
            this.instructionsIcon.BackColor = System.Drawing.Color.Transparent;
            this.instructionsIcon.BackgroundImage = global::ChevEscape.Properties.Resources.instructions;
            this.instructionsIcon.Location = new System.Drawing.Point(310, 900);
            this.instructionsIcon.Margin = new System.Windows.Forms.Padding(6);
            this.instructionsIcon.Name = "instructionsIcon";
            this.instructionsIcon.Size = new System.Drawing.Size(64, 62);
            this.instructionsIcon.TabIndex = 45;
            this.instructionsIcon.TabStop = false;
            // 
            // progressBar_PB
            // 
            this.progressBar_PB.BackColor = System.Drawing.Color.Transparent;
            this.progressBar_PB.Image = global::ChevEscape.Properties.Resources.progressBarA_p0;
            this.progressBar_PB.Location = new System.Drawing.Point(404, 900);
            this.progressBar_PB.Margin = new System.Windows.Forms.Padding(6);
            this.progressBar_PB.Name = "progressBar_PB";
            this.progressBar_PB.Size = new System.Drawing.Size(64, 62);
            this.progressBar_PB.TabIndex = 44;
            this.progressBar_PB.TabStop = false;
            // 
            // actionTile_submitSwitch
            // 
            this.actionTile_submitSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_submitSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_submitSwitch.Location = new System.Drawing.Point(404, 1065);
            this.actionTile_submitSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_submitSwitch.Name = "actionTile_submitSwitch";
            this.actionTile_submitSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_submitSwitch.TabIndex = 41;
            this.actionTile_submitSwitch.TabStop = false;
            // 
            // switch_submit
            // 
            this.switch_submit.BackColor = System.Drawing.Color.Transparent;
            this.switch_submit.Image = global::ChevEscape.Properties.Resources.purple_switchButton_idle;
            this.switch_submit.Location = new System.Drawing.Point(404, 973);
            this.switch_submit.Margin = new System.Windows.Forms.Padding(6);
            this.switch_submit.Name = "switch_submit";
            this.switch_submit.Size = new System.Drawing.Size(64, 62);
            this.switch_submit.TabIndex = 40;
            this.switch_submit.TabStop = false;
            // 
            // switch_beginPuzzle
            // 
            this.switch_beginPuzzle.BackColor = System.Drawing.Color.Transparent;
            this.switch_beginPuzzle.Image = global::ChevEscape.Properties.Resources.switchButton_idle;
            this.switch_beginPuzzle.Location = new System.Drawing.Point(506, 973);
            this.switch_beginPuzzle.Margin = new System.Windows.Forms.Padding(6);
            this.switch_beginPuzzle.Name = "switch_beginPuzzle";
            this.switch_beginPuzzle.Size = new System.Drawing.Size(64, 62);
            this.switch_beginPuzzle.TabIndex = 39;
            this.switch_beginPuzzle.TabStop = false;
            // 
            // actionTile_beginSwitch
            // 
            this.actionTile_beginSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_beginSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_beginSwitch.Location = new System.Drawing.Point(506, 1065);
            this.actionTile_beginSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_beginSwitch.Name = "actionTile_beginSwitch";
            this.actionTile_beginSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_beginSwitch.TabIndex = 38;
            this.actionTile_beginSwitch.TabStop = false;
            // 
            // flashBin_Yellow
            // 
            this.flashBin_Yellow.BackColor = System.Drawing.Color.Transparent;
            this.flashBin_Yellow.BackgroundImage = global::ChevEscape.Properties.Resources.neutral_flashbin;
            this.flashBin_Yellow.Image = global::ChevEscape.Properties.Resources.yellow_flashbin;
            this.flashBin_Yellow.Location = new System.Drawing.Point(602, 875);
            this.flashBin_Yellow.Margin = new System.Windows.Forms.Padding(6);
            this.flashBin_Yellow.Name = "flashBin_Yellow";
            this.flashBin_Yellow.Size = new System.Drawing.Size(64, 62);
            this.flashBin_Yellow.TabIndex = 37;
            this.flashBin_Yellow.TabStop = false;
            // 
            // switch_yellowBin
            // 
            this.switch_yellowBin.BackColor = System.Drawing.Color.Transparent;
            this.switch_yellowBin.Image = global::ChevEscape.Properties.Resources.yellow_switchButton_idle;
            this.switch_yellowBin.Location = new System.Drawing.Point(602, 973);
            this.switch_yellowBin.Margin = new System.Windows.Forms.Padding(6);
            this.switch_yellowBin.Name = "switch_yellowBin";
            this.switch_yellowBin.Size = new System.Drawing.Size(64, 62);
            this.switch_yellowBin.TabIndex = 36;
            this.switch_yellowBin.TabStop = false;
            // 
            // actionTile_yellowSwitch
            // 
            this.actionTile_yellowSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_yellowSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_yellowSwitch.Location = new System.Drawing.Point(602, 1065);
            this.actionTile_yellowSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_yellowSwitch.Name = "actionTile_yellowSwitch";
            this.actionTile_yellowSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_yellowSwitch.TabIndex = 35;
            this.actionTile_yellowSwitch.TabStop = false;
            // 
            // flashBin_Green
            // 
            this.flashBin_Green.BackColor = System.Drawing.Color.Transparent;
            this.flashBin_Green.BackgroundImage = global::ChevEscape.Properties.Resources.neutral_flashbin;
            this.flashBin_Green.Image = global::ChevEscape.Properties.Resources.green_flashbin;
            this.flashBin_Green.Location = new System.Drawing.Point(696, 875);
            this.flashBin_Green.Margin = new System.Windows.Forms.Padding(6);
            this.flashBin_Green.Name = "flashBin_Green";
            this.flashBin_Green.Size = new System.Drawing.Size(64, 62);
            this.flashBin_Green.TabIndex = 34;
            this.flashBin_Green.TabStop = false;
            // 
            // switch_greenBin
            // 
            this.switch_greenBin.BackColor = System.Drawing.Color.Transparent;
            this.switch_greenBin.Image = global::ChevEscape.Properties.Resources.green_switchButton_idle;
            this.switch_greenBin.Location = new System.Drawing.Point(696, 973);
            this.switch_greenBin.Margin = new System.Windows.Forms.Padding(6);
            this.switch_greenBin.Name = "switch_greenBin";
            this.switch_greenBin.Size = new System.Drawing.Size(64, 62);
            this.switch_greenBin.TabIndex = 33;
            this.switch_greenBin.TabStop = false;
            // 
            // actionTile_greenSwitch
            // 
            this.actionTile_greenSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_greenSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_greenSwitch.Location = new System.Drawing.Point(696, 1065);
            this.actionTile_greenSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_greenSwitch.Name = "actionTile_greenSwitch";
            this.actionTile_greenSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_greenSwitch.TabIndex = 32;
            this.actionTile_greenSwitch.TabStop = false;
            // 
            // flashBin_Red
            // 
            this.flashBin_Red.BackColor = System.Drawing.Color.Transparent;
            this.flashBin_Red.BackgroundImage = global::ChevEscape.Properties.Resources.neutral_flashbin;
            this.flashBin_Red.Image = global::ChevEscape.Properties.Resources.red_flashbin;
            this.flashBin_Red.Location = new System.Drawing.Point(806, 875);
            this.flashBin_Red.Margin = new System.Windows.Forms.Padding(6);
            this.flashBin_Red.Name = "flashBin_Red";
            this.flashBin_Red.Size = new System.Drawing.Size(64, 62);
            this.flashBin_Red.TabIndex = 31;
            this.flashBin_Red.TabStop = false;
            // 
            // switch_redBin
            // 
            this.switch_redBin.BackColor = System.Drawing.Color.Transparent;
            this.switch_redBin.Image = global::ChevEscape.Properties.Resources.red_switchButton_idle;
            this.switch_redBin.Location = new System.Drawing.Point(806, 973);
            this.switch_redBin.Margin = new System.Windows.Forms.Padding(6);
            this.switch_redBin.Name = "switch_redBin";
            this.switch_redBin.Size = new System.Drawing.Size(64, 62);
            this.switch_redBin.TabIndex = 30;
            this.switch_redBin.TabStop = false;
            // 
            // actionTile_redSwitch
            // 
            this.actionTile_redSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_redSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_redSwitch.Location = new System.Drawing.Point(806, 1065);
            this.actionTile_redSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_redSwitch.Name = "actionTile_redSwitch";
            this.actionTile_redSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_redSwitch.TabIndex = 29;
            this.actionTile_redSwitch.TabStop = false;
            // 
            // flashBin_Blue
            // 
            this.flashBin_Blue.BackColor = System.Drawing.Color.Transparent;
            this.flashBin_Blue.BackgroundImage = global::ChevEscape.Properties.Resources.neutral_flashbin;
            this.flashBin_Blue.Image = global::ChevEscape.Properties.Resources.blue_flashbin;
            this.flashBin_Blue.Location = new System.Drawing.Point(904, 875);
            this.flashBin_Blue.Margin = new System.Windows.Forms.Padding(6);
            this.flashBin_Blue.Name = "flashBin_Blue";
            this.flashBin_Blue.Size = new System.Drawing.Size(64, 62);
            this.flashBin_Blue.TabIndex = 28;
            this.flashBin_Blue.TabStop = false;
            // 
            // switch_blueBin
            // 
            this.switch_blueBin.BackColor = System.Drawing.Color.Transparent;
            this.switch_blueBin.Image = global::ChevEscape.Properties.Resources.blue_switchButton_idle;
            this.switch_blueBin.Location = new System.Drawing.Point(904, 973);
            this.switch_blueBin.Margin = new System.Windows.Forms.Padding(6);
            this.switch_blueBin.Name = "switch_blueBin";
            this.switch_blueBin.Size = new System.Drawing.Size(64, 62);
            this.switch_blueBin.TabIndex = 27;
            this.switch_blueBin.TabStop = false;
            // 
            // actionTile_blueSwitch
            // 
            this.actionTile_blueSwitch.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_blueSwitch.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_blueSwitch.Location = new System.Drawing.Point(904, 1065);
            this.actionTile_blueSwitch.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_blueSwitch.Name = "actionTile_blueSwitch";
            this.actionTile_blueSwitch.Size = new System.Drawing.Size(64, 62);
            this.actionTile_blueSwitch.TabIndex = 26;
            this.actionTile_blueSwitch.TabStop = false;
            // 
            // indicatorPB
            // 
            this.indicatorPB.BackColor = System.Drawing.Color.Transparent;
            this.indicatorPB.Image = global::ChevEscape.Properties.Resources.indicator_neutral;
            this.indicatorPB.Location = new System.Drawing.Point(1008, 875);
            this.indicatorPB.Margin = new System.Windows.Forms.Padding(6);
            this.indicatorPB.Name = "indicatorPB";
            this.indicatorPB.Size = new System.Drawing.Size(64, 62);
            this.indicatorPB.TabIndex = 25;
            this.indicatorPB.TabStop = false;
            // 
            // actionTile_Door
            // 
            this.actionTile_Door.BackColor = System.Drawing.Color.Transparent;
            this.actionTile_Door.Image = global::ChevEscape.Properties.Resources.actionTile;
            this.actionTile_Door.Location = new System.Drawing.Point(1008, 973);
            this.actionTile_Door.Margin = new System.Windows.Forms.Padding(6);
            this.actionTile_Door.Name = "actionTile_Door";
            this.actionTile_Door.Size = new System.Drawing.Size(64, 62);
            this.actionTile_Door.TabIndex = 8;
            this.actionTile_Door.TabStop = false;
            // 
            // door_A
            // 
            this.door_A.BackColor = System.Drawing.Color.Transparent;
            this.door_A.Image = global::ChevEscape.Properties.Resources.doorTypeA;
            this.door_A.Location = new System.Drawing.Point(1008, 1065);
            this.door_A.Margin = new System.Windows.Forms.Padding(6);
            this.door_A.Name = "door_A";
            this.door_A.Size = new System.Drawing.Size(64, 62);
            this.door_A.TabIndex = 3;
            this.door_A.TabStop = false;
            // 
            // heartContainerA
            // 
            this.heartContainerA.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerA.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerA.Location = new System.Drawing.Point(234, 900);
            this.heartContainerA.Margin = new System.Windows.Forms.Padding(6);
            this.heartContainerA.Name = "heartContainerA";
            this.heartContainerA.Size = new System.Drawing.Size(64, 62);
            this.heartContainerA.TabIndex = 51;
            this.heartContainerA.TabStop = false;
            // 
            // heartContainerC
            // 
            this.heartContainerC.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerC.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerC.Location = new System.Drawing.Point(234, 1046);
            this.heartContainerC.Margin = new System.Windows.Forms.Padding(6);
            this.heartContainerC.Name = "heartContainerC";
            this.heartContainerC.Size = new System.Drawing.Size(64, 62);
            this.heartContainerC.TabIndex = 53;
            this.heartContainerC.TabStop = false;
            // 
            // heartContainerB
            // 
            this.heartContainerB.BackColor = System.Drawing.Color.Transparent;
            this.heartContainerB.Image = global::ChevEscape.Properties.Resources.heart_full;
            this.heartContainerB.Location = new System.Drawing.Point(234, 973);
            this.heartContainerB.Margin = new System.Windows.Forms.Padding(6);
            this.heartContainerB.Name = "heartContainerB";
            this.heartContainerB.Size = new System.Drawing.Size(64, 62);
            this.heartContainerB.TabIndex = 52;
            this.heartContainerB.TabStop = false;
            // 
            // button_mute
            // 
            this.button_mute.BackColor = System.Drawing.Color.Transparent;
            this.button_mute.Image = global::ChevEscape.Properties.Resources.Unmuted;
            this.button_mute.Location = new System.Drawing.Point(1128, 97);
            this.button_mute.Margin = new System.Windows.Forms.Padding(6);
            this.button_mute.Name = "button_mute";
            this.button_mute.Size = new System.Drawing.Size(64, 62);
            this.button_mute.TabIndex = 54;
            this.button_mute.TabStop = false;
            this.button_mute.Click += new System.EventHandler(this.button_mute_Click);
            // 
            // MemoryRoom
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.BurlyWood;
            this.ClientSize = new System.Drawing.Size(1216, 1169);
            this.Controls.Add(this.button_mute);
            this.Controls.Add(this.heartContainerA);
            this.Controls.Add(this.heartContainerC);
            this.Controls.Add(this.heartContainerB);
            this.Controls.Add(this.button_pause);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.main_player);
            this.Controls.Add(this.actionTile_Instructions);
            this.Controls.Add(this.instructionsIcon);
            this.Controls.Add(this.progressBar_PB);
            this.Controls.Add(this.actionTile_submitSwitch);
            this.Controls.Add(this.switch_submit);
            this.Controls.Add(this.switch_beginPuzzle);
            this.Controls.Add(this.actionTile_beginSwitch);
            this.Controls.Add(this.flashBin_Yellow);
            this.Controls.Add(this.switch_yellowBin);
            this.Controls.Add(this.actionTile_yellowSwitch);
            this.Controls.Add(this.flashBin_Green);
            this.Controls.Add(this.switch_greenBin);
            this.Controls.Add(this.actionTile_greenSwitch);
            this.Controls.Add(this.flashBin_Red);
            this.Controls.Add(this.switch_redBin);
            this.Controls.Add(this.actionTile_redSwitch);
            this.Controls.Add(this.flashBin_Blue);
            this.Controls.Add(this.switch_blueBin);
            this.Controls.Add(this.actionTile_blueSwitch);
            this.Controls.Add(this.indicatorPB);
            this.Controls.Add(this.actionTile_Door);
            this.Controls.Add(this.door_A);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.MaximumSize = new System.Drawing.Size(1216, 1169);
            this.MinimumSize = new System.Drawing.Size(1216, 1169);
            this.Name = "MemoryRoom";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MemoryRoom";
            this.Load += new System.EventHandler(this.MemoryRoom_Load);
            this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.MemoryRoom_KeyUp);
            ((System.ComponentModel.ISupportInitialize)(this.button_pause)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.main_player)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Instructions)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.instructionsIcon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.progressBar_PB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_submitSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_submit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_beginPuzzle)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_beginSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Yellow)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_yellowBin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_yellowSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Green)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_greenBin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_greenSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Red)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_redBin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_redSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.flashBin_Blue)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.switch_blueBin)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_blueSwitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.indicatorPB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.actionTile_Door)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.door_A)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerA)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.heartContainerB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.button_mute)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox main_player;
        private System.Windows.Forms.PictureBox door_A;
        private System.Windows.Forms.PictureBox actionTile_Door;
        private System.Windows.Forms.PictureBox indicatorPB;
        private System.Windows.Forms.PictureBox actionTile_blueSwitch;
        private System.Windows.Forms.PictureBox switch_blueBin;
        private System.Windows.Forms.PictureBox flashBin_Blue;
        private System.Windows.Forms.PictureBox actionTile_redSwitch;
        private System.Windows.Forms.PictureBox switch_redBin;
        private System.Windows.Forms.PictureBox flashBin_Red;
        private System.Windows.Forms.PictureBox actionTile_greenSwitch;
        private System.Windows.Forms.PictureBox switch_greenBin;
        private System.Windows.Forms.PictureBox flashBin_Green;
        private System.Windows.Forms.PictureBox actionTile_yellowSwitch;
        private System.Windows.Forms.PictureBox switch_yellowBin;
        private System.Windows.Forms.PictureBox flashBin_Yellow;
        private System.Windows.Forms.PictureBox actionTile_beginSwitch;
        private System.Windows.Forms.PictureBox switch_beginPuzzle;
        private System.Windows.Forms.PictureBox switch_submit;
        private System.Windows.Forms.PictureBox actionTile_submitSwitch;
        private System.Windows.Forms.PictureBox button_close;
        private System.Windows.Forms.PictureBox button_pause;
        private System.Windows.Forms.PictureBox progressBar_PB;
        private System.Windows.Forms.PictureBox instructionsIcon;
        private System.Windows.Forms.PictureBox actionTile_Instructions;
        private System.Windows.Forms.PictureBox heartContainerA;
        private System.Windows.Forms.PictureBox heartContainerC;
        private System.Windows.Forms.PictureBox heartContainerB;
        private System.Windows.Forms.PictureBox button_mute;
    }
}